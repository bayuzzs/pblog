@props(['class' => ''])
<div id="dismiss-alert-{{ cleanString($slot) }}"
		class="{{ $class }} rounded-lg border border-teal-300 bg-teal-50 p-4 text-sm text-teal-800 transition duration-300 hs-removing:translate-x-5 hs-removing:opacity-0 dark:border-teal-900 dark:bg-teal-800/10 dark:text-teal-500"
		role="alert">
		<div class="flex">
				<div class="flex-shrink-0">
						<svg class="size-4 mt-0.5 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
								viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
								stroke-linejoin="round">
								<path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path>
								<path d="m9 12 2 2 4-4"></path>
						</svg>
				</div>
				<div class="ms-2">
						<div class="text-sm">
								{{ $slot }}
						</div>
				</div>
				<div class="ms-auto ps-3">
						<div class="-mx-1.5 -my-1.5">
								<button type="button"
										class="inline-flex rounded-lg bg-teal-50 p-1.5 text-teal-500 hover:bg-teal-100 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-teal-50 dark:bg-transparent dark:text-teal-600 dark:hover:bg-teal-800/50"
										data-hs-remove-element="#dismiss-alert-{{ cleanString($slot) }}">
										<span class="sr-only">Dismiss</span>
										<svg class="size-4 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
												viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
												stroke-linejoin="round">
												<path d="M18 6 6 18"></path>
												<path d="m6 6 12 12"></path>
										</svg>
								</button>
						</div>
				</div>
		</div>
</div>
