<?php

namespace App\Models\DataMaster;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JenisDokumen extends Model
    {
    use HasFactory;
    protected $table = 'jenis_dokumen';
    protected $primaryKey = 'kodeJenisDokumen';
    public $incrementing = false;
    public $timestamps = true;

    protected $fillable = [
        'kodeJenisDokumen',
        'namaDokumen',
    ];
    }

