<?php

namespace App\Models\DataMaster;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pelabuhan extends Model
    {
    use HasFactory;
    protected $table = 'pelabuhan';
    protected $primaryKey = 'kodePelabuhan';
    public $incrementing = false;
    public $timestamps = true;
    protected $fillable = [
        'kodePelabuhan',
        'namaPelabuhan',
        'namaNegara',
    ];
    }
