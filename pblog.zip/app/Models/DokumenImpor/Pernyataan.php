<?php

namespace App\Models\DokumenImpor;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pernyataan extends Model
    {
    use HasFactory;

    protected $primaryKey = 'pernyataanId';
    protected $table = 'pernyataan';

    protected $fillable = [
        'jabatan',
        'nama',
        'tempat',
        'tanggal',
        'nomorAju',
    ];

    // Relasi dengan tabel 'dokumen_impor' melalui 'nomorAju'
    public function dokumenImpor()
        {
        return $this->belongsTo(DokumenImpor::class, 'nomorAju', 'nomorAju');
        }
    }

